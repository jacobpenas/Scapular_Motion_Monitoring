#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>
#include "f28x_project.h"

// Defines
#define I2C_SLAVE_ADDR      0x02U               // update for each slave device
#define n_bits              8
#define GPIO_PIN_SDAA       21U                 // GPIO number for I2C SDAA
#define GPIO_PIN_SCLA       20U                 // GPIO number for I2C SCLA
#define GPIO_PIN_RX         16U                 // GPIO number for receiver input
#define GPIO_PIN_TX         40
#define tx_pin_config       GPIO_40_GPIO40


// Globals
typedef enum {
    receive_trigger,
    transmit_pulse,
    receive_pulse,
    send_data
} states;
volatile states state = receive_trigger;
uint8_t I2C_TXdata[250];
uint8_t index_data[250];
static const uint8_t id = 2;                    // update for each slave device

// Function Prototypes
void GPIO_Init(void);
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress);
__interrupt void I2CISR(void);


void main(void)
{
    // Initialize device & 120MHz clock speed
    Device_init();
    SysCtl_setClock(
        SYSCTL_OSCSRC_OSC2  |               // Use internal oscillator
        SYSCTL_IMULT(12)    |               // Set PLL multiplier
        SYSCTL_REFDIV(1)    |               // Reference clock divider
        SYSCTL_ODIV(1)      |               // Output clock divider
        SYSCTL_SYSDIV(1)    |               // System clock divider
        SYSCTL_PLL_ENABLE                   // Enable the PLL
    );
    Device_initGPIO();

    // Initialize GPIO pins for necessary signals
    GPIO_Init();

    // .Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR)
    InitPieVectTable();

    // Register the interrupt ISR
    EALLOW;                                 // This is needed to write to EALLOW protected registers
    PieVectTable.I2CA_INT = &I2CISR;
    EDIS;                                   // This is needed to disable write to EALLOW protected registers

    // Enable Interrupts
    PieCtrlRegs.PIEIER8.all = 0x1;          // Enable PIE Group 8 INT8
    IER |= M_INT8;                          // Enable CPU INT8
    EINT;                                   // Enable Global Interrupts
    EnableInterrupts();

    // Initialize I2C Module
    I2CSlave_Init(I2C_SLAVE_ADDR);

    volatile uint32_t *gpioDataReg;
    uint32_t pinMask;
    gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((GPIO_PIN_TX / 32U) * GPIO_DATA_REGS_STEP);
    pinMask = (uint32_t)1U << (GPIO_PIN_TX % 32U);

    int i, j;
    uint16_t array[250]={0};
    uint16_t input[313]={0};
    uint16_t temp[64]={ 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1,
                        1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1,
                        1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0,
                        0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0 };

    int k, l, num;
    uint16_t s = 0;
    uint16_t t[250] = {0};

    for(;;)
    {
        switch(state) {

     // wait until master sends trigger
        case receive_trigger:
/*      handled by ISR                                                                        */
            break;

     // transmit template signal
        case transmit_pulse:
/*      transmit pulse: 1010100101100101100101101010100110011010010110100101100110011010      */

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
            gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

            state = receive_pulse;
            break;

     // read resulting signal
        case receive_pulse:
/*      receive GPIO pulse data into array                                                    */
// 4 assembly instructions per high level instruction
            array[0] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[1] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[2] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[3] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[4] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[5] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[6] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[7] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[8] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[9] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[10] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[11] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[12] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[13] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[14] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[15] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[16] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[17] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[18] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[19] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[20] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[21] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[22] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[23] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[24] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[25] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[26] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[27] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[28] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[29] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[30] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[31] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[32] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[33] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[34] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[35] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[36] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[37] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[38] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[39] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[40] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[41] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[42] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[43] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[44] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[45] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[46] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[47] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[48] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[49] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[50] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[51] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[52] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[53] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[54] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[55] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[56] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[57] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[58] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[59] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[60] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[61] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[62] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[63] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[64] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[65] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[66] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[67] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[68] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[69] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[70] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[71] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[72] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[73] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[74] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[75] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[76] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[77] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[78] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[79] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[80] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[81] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[82] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[83] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[84] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[85] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[86] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[87] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[88] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[89] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[90] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[91] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[92] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[93] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[94] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[95] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[96] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[97] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[98] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[99] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[100] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[101] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[102] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[103] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[104] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[105] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[106] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[107] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[108] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[109] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[110] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[111] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[112] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[113] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[114] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[115] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[116] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[117] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[118] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[119] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[120] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[121] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[122] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[123] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[124] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[125] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[126] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[127] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[128] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[129] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[130] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[131] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[132] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[133] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[134] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[135] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[136] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[137] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[138] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[139] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[140] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[141] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[142] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[143] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[144] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[145] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[146] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[147] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[148] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[149] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[150] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[151] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[152] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[153] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[154] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[155] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[156] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[157] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[158] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[159] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[160] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[161] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[162] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[163] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[164] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[165] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[166] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[167] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[168] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[169] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[170] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[171] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[172] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[173] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[174] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[175] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[176] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[177] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[178] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[179] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[180] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[181] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[182] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[183] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[184] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[185] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[186] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[187] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[188] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[189] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[190] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[191] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[192] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[193] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[194] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[195] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[196] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[197] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[198] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[199] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[200] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[201] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[202] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[203] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[204] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[205] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[206] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[207] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[208] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[209] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[210] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[211] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[212] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[213] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[214] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[215] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[216] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[217] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[218] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[219] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[220] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[221] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[222] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[223] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[224] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[225] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[226] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[227] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[228] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[229] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[230] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[231] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[232] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[233] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[234] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[235] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[236] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[237] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[238] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[239] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[240] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[241] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[242] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[243] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[244] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[245] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[246] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[247] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[248] = GpioDataRegs.GPADAT.bit.GPIO16;
            array[249] = GpioDataRegs.GPADAT.bit.GPIO16;

            i = 0;
            j = 0;
            while (i <= 249) {
                if (array[i] == array[i+1] && array[i+1] == array[i+2] && (array[i+2] == array[i+3] || array[i+2] != array[i+3])) {
                    // 3 or 4 successive 0/1 -> store 2 elements
                    input[j] = array[i];
                    input[j+1] = array[i+1];
                    i += (array[i+2] == array[i+3]) ? 4 : 3;
                    j += 2;
                }
                else if (array[i] == array[i+1]) {
                    // 2 successive 0/1 -> store 1 element
                    input[j] = array[i];
                    i += 2;
                    j += 1;
                }
                else {
                    // 1 successive 0/1 -> store 1 element
                    input[j] = array[i];
                    i += 1;
                    j += 1;
                }
            }

            i = 0;
            num = 0;
            for (k = 0; k <= 249; k++) {
                s = 0;  // Reset sum at the beginning of each k iteration
                for (l = 0; l <= 63; l++) {
                    s += (~(input[k + l] ^ temp[l])) & 0x0001;  // Add result to s
                }
                t[k] = s;  // Store the sum for k
                if (t[k] >= 60) {
                    I2C_TXdata[num] = t[k];
                    index_data[num++] = k;
                }
                else if (k == 249 && num == 0) {
                    I2C_TXdata[num] = 0;
                    index_data[num] = 250;
                }
            }
            // clear array, input, t
            memset(array, 0, sizeof(array));
            memset(input, 0, sizeof(input));
            memset(t, 0, sizeof(t));

            state = send_data;
            break;
     // send result of template matching algorithm to master
        case send_data:
/*      handled by ISR                                                                        */
            break;
        }
    }
}

void GPIO_Init(void) {
    // I2C pins
    GPIO_SetupPinMux(GPIO_PIN_SDAA, GPIO_MUX_CPU1, 11);
    GPIO_SetupPinOptions(GPIO_PIN_SDAA, GPIO_OUTPUT, GPIO_PULLUP);
    GPIO_SetupPinMux(GPIO_PIN_SCLA, GPIO_MUX_CPU1, 11);
    GPIO_SetupPinOptions(GPIO_PIN_SCLA, GPIO_OUTPUT, GPIO_PULLUP);

//    GPIO_SetupPinMux(GPIO_PIN_RX, GPIO_MUX_CPU1, 0);
//    GPIO_SetupPinOptions(GPIO_PIN_RX, GPIO_INPUT, GPIO_SYNC);

    GPIO_setPinConfig(GPIO_16_GPIO16);
    GPIO_setDirectionMode(GPIO_PIN_RX, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(GPIO_PIN_RX, GPIO_PIN_TYPE_STD);

    GPIO_setPinConfig(tx_pin_config);
    GPIO_setDirectionMode(GPIO_PIN_TX, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(GPIO_PIN_TX, GPIO_PIN_TYPE_STD);
}

// Function to configure I2CA as Slave Receiver
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress)
{
    EALLOW;
    // Reset the I2C Module
    I2caRegs.I2CMDR.all &= ~(0x20U);

    // Configure I2C as slave in Receive mode
    I2caRegs.I2CMDR.bit.MST = 0x0U;
    I2caRegs.I2CMDR.bit.TRX = 0x0U;

    // Set the bit count to 8 bits per data byte
    I2caRegs.I2CMDR.bit.BC = 0x0U;

    // Set emulation mode to FREE
    I2caRegs.I2CMDR.bit.FREE = 0x1;

    // Configure I2C own address
    I2caRegs.I2COAR.all = I2CSlave_OwnAddress;      // Own address

    //Clear all status
    I2caRegs.I2CSTR.all = 0xFFFF;

    // Enable I2C Interrupts- AAS, STOP, XRDY and RRDY
    I2caRegs.I2CIER.all = 0x78;

    // Take I2C out of reset
    I2caRegs.I2CMDR.all |= 0x0020;

    EDIS;
}


// I2C Interrupt Service Routine
__interrupt void I2CISR(void)
{
    // Handle I2C interrupt
    uint16_t IntSource, tx_index;
    uint8_t rx_data;

    // Read Interrupt source
    IntSource = I2caRegs.I2CISRC.all;

    // Interrupt source
    if(IntSource == 0x7U)   // AAS interrupt
    {
        if(I2caRegs.I2CSTR.bit.SDIR)
        {
            // Configure slave as transmitter
            I2caRegs.I2CMDR.bit.TRX = 0x1U;
         }
         else
         {
             // Configure slave as receiver
             I2caRegs.I2CMDR.bit.TRX = 0x0U;
        }
    }
    else if(IntSource == 0x6U) // STOP interrupt
    {
        // reset index
        tx_index = 0;
    }
    else if (IntSource == 0x4U)  // RRDY interrupt
    {
        // act only if receiving trigger
        if (state == receive_trigger) {
            // Read the received data into RX buffer
            while(I2caRegs.I2CSTR.bit.RRDY != 0)
            {
                // read received data
                rx_data = I2caRegs.I2CDRR.bit.DATA;
            }

            // update state if proper trigger is received
            if (rx_data == id) {
                state = transmit_pulse;
            }
            else {
                state = receive_pulse;
            }
        }
    }
    else if (IntSource == 0x5U) // XRDY interrupt
    {
        // only act if sending data
        if (state == send_data) {
            // configure slave as transmitter
            I2caRegs.I2CMDR.bit.TRX = 1;

            // Disable the interrupt till all the bytes are sent
            I2caRegs.I2CIER.bit.XRDY = 0;

            // transmit the bytes (sums of ~XOR operations greater than threshold)
            for(tx_index = 0; tx_index < 250; tx_index++)
            {
                I2caRegs.I2CDXR.bit.DATA = I2C_TXdata[tx_index];

                // wait till byte is sent
                while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);

                // clear the byte sent
                I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
            }
            // clear I2C_TXdata
            memset(I2C_TXdata, 0, sizeof(I2C_TXdata));

            // transmit index data
            tx_index = 0;
            for (tx_index = 0; tx_index < 250; tx_index++)
            {
                I2caRegs.I2CDXR.bit.DATA = index_data[tx_index];
                while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);
                I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
            }
            // clear index_data
            memset(index_data, -1, sizeof(index_data));

            // Enable the interrupt after all the bytes are sent
            I2caRegs.I2CIER.bit.XRDY = 1;

            // Update state (after all data is transferred)
            state = receive_trigger;
        }
    }

    // Clear the current interrupt and enable future I2C (PIE Group 8) interrupts
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
 }
