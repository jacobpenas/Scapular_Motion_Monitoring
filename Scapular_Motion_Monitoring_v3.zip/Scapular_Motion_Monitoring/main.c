#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>

#define tx_pin        20
#define tx_pin_config GPIO_20_GPIO20
#define n_bits        8

char data[] = "hello!";
volatile uint8_t tx_index;
volatile uint8_t rx_data;
volatile uint8_t template = 0xAA;
volatile uint8_t template_array[8] = {1, 0, 1, 0, 1, 0, 1, 0};

//__interrupt void i2cISR();
//void i2c_enable();


void main(void)
{

    Device_init();
    SysCtl_setClock(
        SYSCTL_OSCSRC_OSC2  |               // Use internal oscillator
        SYSCTL_IMULT(12)    |               // Set PLL multiplier
        SYSCTL_REFDIV(1)    |               // Reference clock divider
        SYSCTL_ODIV(1)      |               // Output clock divider
        SYSCTL_SYSDIV(1)    |               // System clock divider
        SYSCTL_PLL_ENABLE                   // Enable the PLL
    );
    Device_initGPIO();
//    i2c_enable();

    SysCtl_selectClockOutSource(SYSCTL_CLOCKOUT_SYSCLK);
    SysCtl_setXClk(SYSCTL_XCLKOUT_DIV_1);
    GPIO_setPinConfig(GPIO_16_XCLKOUT);
    GPIO_setDirectionMode(16, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(16, GPIO_PIN_TYPE_STD);

    GPIO_setPinConfig(tx_pin_config);
    GPIO_setDirectionMode(tx_pin, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(tx_pin, GPIO_PIN_TYPE_STD);

    volatile uint32_t *gpioDataReg;
    uint32_t pinMask;
    gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((tx_pin / 32U) * GPIO_DATA_REGS_STEP);
    pinMask = (uint32_t)1U << (tx_pin % 32U);

    for(;;)
    {
        // 1010 1010
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

    }

}


__interrupt void i2cISR()
{
    uint32_t status = I2C_getInterruptStatus(myI2C0_BASE);

    if (status & I2C_INT_ADDR_TARGET)
    {
        tx_index = 0;
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_ADDR_TARGET);
    }

    if (status & I2C_INT_RX_DATA_RDY)
    {
        rx_data = I2C_getData(myI2C0_BASE);
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_RX_DATA_RDY);
    }

    if (status & I2C_INT_TX_DATA_RDY)
    {
        if (tx_index < sizeof(data))
        {
            I2C_putData(myI2C0_BASE, data[tx_index++]);
        }
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_TX_DATA_RDY);
    }

    if (status & I2C_INT_STOP_CONDITION)
    {
        tx_index = 0;
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_STOP_CONDITION);
    }

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP8);
}

void i2c_enable()
{
    GPIO_setPinConfig(myI2C0_I2CSDA_PIN_CONFIG);
    GPIO_setPadConfig(myI2C0_I2CSDA_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
    GPIO_setPinConfig(myI2C0_I2CSCL_PIN_CONFIG);
    GPIO_setPadConfig(myI2C0_I2CSCL_GPIO, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);

    I2C_disableModule(myI2C0_BASE);
    I2C_configureModuleFrequency(myI2C0_BASE, DEVICE_SYSCLK_FREQ);
    I2C_setConfig(myI2C0_BASE, I2C_TARGET_RECEIVE_MODE);
    I2C_setOwnAddress(myI2C0_BASE, myI2C0_OWN_ADDRESS);
    I2C_setTargetAddress(myI2C0_BASE, myI2C0_TARGET_ADDRESS);
    I2C_setBitCount(myI2C0_BASE, I2C_BITCOUNT_8);
    I2C_setDataCount(myI2C0_BASE, 1);
    I2C_setAddressMode(myI2C0_BASE, I2C_ADDR_MODE_7BITS);
    I2C_disableFIFO(myI2C0_BASE);
    I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_ADDR_TARGET | I2C_INT_RX_DATA_RDY | I2C_INT_STOP_CONDITION | I2C_INT_TX_DATA_RDY);
    I2C_enableInterrupt(myI2C0_BASE, I2C_INT_ADDR_TARGET | I2C_INT_RX_DATA_RDY | I2C_INT_STOP_CONDITION | I2C_INT_TX_DATA_RDY);
    I2C_setEmulationMode(myI2C0_BASE, I2C_EMULATION_STOP_SCL_LOW);

    Interrupt_initModule();
    Interrupt_initVectorTable();
    Interrupt_register(INT_I2CA, &i2cISR);
    Interrupt_enable(INT_I2CA);

    I2C_enableModule(myI2C0_BASE);

    EINT;
    ERTM;
}

