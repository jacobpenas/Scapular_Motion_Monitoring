#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>
#include "f28x_project.h"


#define tx_pin        40
#define tx_pin_config GPIO_40_GPIO40
#define n_bits        8
//#define SLAVE_ADDRESS 0x6A

char data[] = "hello!";
volatile uint8_t tx_index;
volatile uint8_t rx_data;
volatile uint8_t template = 0xAA;
volatile uint8_t template_array[8] = {1, 0, 1, 0, 1, 0, 1, 0};


// Interrupt flag to track the communication
volatile uint8_t sendDataFlag = 0;

/*
__interrupt void i2cISR();
void i2c_enable();
*/

//
// Defines
//
#define I2C_SLAVE_ADDR 0x01U
#define MAX_BUFFER_SIZE 0x10
#define I2C_NUMBYTES    0x2U

//
// I2C GPIO pins
//
#define GPIO_PIN_SDAA        21U  // GPIO number for I2C SDAA
#define GPIO_PIN_SCLA        20U  // GPIO number for I2C SCLA
//

//
// Globals
//
uint16_t I2C_TXdata[MAX_BUFFER_SIZE];
uint16_t I2C_RXdata[MAX_BUFFER_SIZE];
uint16_t PassCount=0x0, FailCount =0x0;

//
// Function Prototypes
//
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress);
__interrupt void I2CISR(void);


void main(void)
{
    uint16_t index = 0U;
    Device_init();
    SysCtl_setClock(
        SYSCTL_OSCSRC_OSC2  |               // Use internal oscillator
        SYSCTL_IMULT(12)    |               // Set PLL multiplier
        SYSCTL_REFDIV(1)    |               // Reference clock divider
        SYSCTL_ODIV(1)      |               // Output clock divider
        SYSCTL_SYSDIV(1)    |               // System clock divider
        SYSCTL_PLL_ENABLE                   // Enable the PLL
    );
    Device_initGPIO();
    //i2c_enable();

    SysCtl_selectClockOutSource(SYSCTL_CLOCKOUT_SYSCLK);
    SysCtl_setXClk(SYSCTL_XCLKOUT_DIV_1);
    GPIO_setPinConfig(GPIO_16_XCLKOUT);
    GPIO_setDirectionMode(16, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(16, GPIO_PIN_TYPE_STD);

    GPIO_setPinConfig(tx_pin_config);
    GPIO_setDirectionMode(tx_pin, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(tx_pin, GPIO_PIN_TYPE_STD);

    volatile uint32_t *gpioDataReg;
    uint32_t pinMask;
    gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((tx_pin / 32U) * GPIO_DATA_REGS_STEP);
    pinMask = (uint32_t)1U << (tx_pin % 32U);
    //
     //Configure I2C pins
     //

     GPIO_SetupPinMux(GPIO_PIN_SDAA, GPIO_MUX_CPU1, 11);
     GPIO_SetupPinOptions(GPIO_PIN_SDAA, GPIO_OUTPUT, GPIO_PULLUP);
     GPIO_SetupPinMux(GPIO_PIN_SCLA, GPIO_MUX_CPU1, 11);
     GPIO_SetupPinOptions(GPIO_PIN_SCLA, GPIO_OUTPUT, GPIO_PULLUP);


    //
    // .Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    //
    InitPieCtrl();

    //
    // Disable CPU interrupts and clear all CPU interrupt flags
    //
    IER = 0x0000;
    IFR = 0x0000;

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR)
    //
    InitPieVectTable();

    //
    // Register the interrupt ISR
    //
    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.I2CA_INT = &I2CISR;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    //
    // Enable Interrupts
    //
    PieCtrlRegs.PIEIER8.all = 0x1;          // Enable PIE Group 8 INT8
    IER |= M_INT8;                          // Enable CPU INT8
    EINT;                                   // Enable Global Interrupts

    EnableInterrupts();

    //
    // Set the buffer to some default non-zero value
    //
    for (index=0; index<MAX_BUFFER_SIZE;index++)
    {
        I2C_RXdata[index] = 0xBAADU;
        I2C_TXdata[index] = 0x11 * (index+1);
    }


    // Initialize I2C Module
    I2CSlave_Init(I2C_SLAVE_ADDR);

    for(;;)
    {
        // 1010 1010
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;


        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;


    }

}

/*

__interrupt void i2cISR()
{
    uint32_t status = I2C_getInterruptStatus(myI2C0_BASE);

    if (status & I2C_INT_ADDR_TARGET)
    {
        tx_index = 0;
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_ADDR_TARGET);
    }

    if (status & I2C_INT_RX_DATA_RDY)
    {
        rx_data = I2C_getData(myI2C0_BASE);
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_RX_DATA_RDY);
    }

    if (status & I2C_INT_TX_DATA_RDY)
    {
        if (tx_index < sizeof(data))
        {
            I2C_putData(myI2C0_BASE, data[tx_index++]);
        }
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_TX_DATA_RDY);
    }

    if (status & I2C_INT_STOP_CONDITION)
    {
        tx_index = 0;
        I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_STOP_CONDITION);
    }

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP8);
}

void i2c_enable()
{
    GPIO_setPinConfig(GPIO_21_I2CA_SDA);
    GPIO_setPadConfig(21,  GPIO_PIN_TYPE_PULLUP);
    GPIO_setPinConfig(GPIO_20_I2CA_SCL);
    GPIO_setPadConfig(20, GPIO_PIN_TYPE_PULLUP);

    Interrupt_initModule();
    Interrupt_initVectorTable();

    I2C_disableModule(myI2C0_BASE);
    //I2C_configureModuleFrequency(myI2C0_BASE, DEVICE_SYSCLK_FREQ);
    I2C_setConfig(myI2C0_BASE, I2C_TARGET_RECEIVE_MODE);
    //I2C_setConfig(myI2C0_BASE, I2C_TARGET_SEND_MODE);
    I2C_setOwnAddress(myI2C0_BASE, myI2C0_OWN_ADDRESS);
    //I2C_setOwnAddress(myI2C0_BASE,SLAVE_ADDRESS);
    //I2C_setTargetAddress(myI2C0_BASE, myI2C0_TARGET_ADDRESS);
    I2C_setBitCount(myI2C0_BASE, I2C_BITCOUNT_8);
    I2C_setDataCount(myI2C0_BASE, 1);
    I2C_setAddressMode(myI2C0_BASE, I2C_ADDR_MODE_7BITS);
    I2C_disableFIFO(myI2C0_BASE);
    I2C_clearInterruptStatus(myI2C0_BASE, I2C_INT_ADDR_TARGET | I2C_INT_RX_DATA_RDY | I2C_INT_STOP_CONDITION | I2C_INT_TX_DATA_RDY);
    I2C_enableInterrupt(myI2C0_BASE, I2C_INT_ADDR_TARGET | I2C_INT_RX_DATA_RDY | I2C_INT_STOP_CONDITION | I2C_INT_TX_DATA_RDY);
    //I2C_setEmulationMode(myI2C0_BASE, I2C_EMULATION_STOP_SCL_LOW);
    I2C_setEmulationMode(I2CA_BASE, I2C_EMULATION_FREE_RUN);
    I2C_enableModule(myI2C0_BASE);

    Interrupt_register(INT_I2CA, &i2cISR);
    Interrupt_enable(INT_I2CA);



    EINT;
    ERTM;
}
*/


//
// Function to configure I2CA as Slave Receiver.
//
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress)
{

    //
    // I2C configured as slave receiver mode
    //

    EALLOW;
    //
    // Reset the I2C Module
    //
    I2caRegs.I2CMDR.all &= ~(0x20U);

    //
    // Configure I2C as slave in Receive mode
    //
    I2caRegs.I2CMDR.bit.MST = 0x0U;
    I2caRegs.I2CMDR.bit.TRX = 0x0U;

    //
    // Set the bit count to 8 bits per data byte
    //
    I2caRegs.I2CMDR.bit.BC = 0x0U;

    //
    // Set emulation mode to FREE
    //
    I2caRegs.I2CMDR.bit.FREE = 0x1;

    //
    // Configure I2C own address
    //
    I2caRegs.I2COAR.all = I2CSlave_OwnAddress;      // Own address

    //
    //Clear all status
    //
    I2caRegs.I2CSTR.all = 0xFFFF;

    //
    // Enable I2C Interrupts- AAS, STOP, XRDY and RRDY
    //
    I2caRegs.I2CIER.all = 0x78;

    //
    // Take I2C out of reset
    //
    I2caRegs.I2CMDR.all |= 0x0020;

    EDIS;
}


__interrupt void I2CISR(void)
{
    //
    // Handle I2C interrupt
    //
     uint16_t IntSource, index=0U;
     static bool bDataReceived = false;
     static volatile uint16_t count = 0U;

     //
     // Read Interrupt source
     //
     IntSource = I2caRegs.I2CISRC.all;

     //
     // Interrupt source
     //
     if(IntSource == 0x7U)   // AAS interrupt
     {
         if(I2caRegs.I2CSTR.bit.SDIR)
         {
             // Configure slave as transmitter
             I2caRegs.I2CMDR.bit.TRX = 0x1U;

         }
         else
         {
             //Configure slave as receiver
             I2caRegs.I2CMDR.bit.TRX = 0x0U;

        }
     }
     else if(IntSource == 0x6U) // STOP interrupt
     {
         //
         // Check if data has been received, then do a compare
         //
         if(bDataReceived)
         {
             bDataReceived = false;
             for(index=0; index < count; index++)
             {
                   if(I2C_RXdata[index] == I2C_TXdata[index])
                   {
                       PassCount++;
                   }
                   else
                   {
                       FailCount++;
                   }
             }
             //
             // Reinitialize the RX buffer to non-zero
             //
             if(FailCount ==0)
             {
                 for (index=0; index<count;index++)
                 {
                     I2C_RXdata[index] = 0xBAADU;
                 }
             }
             count =0U;
         }
     }
     else if (IntSource == 0x4U)  // RRDY interrupt
     {
         //
         // Read the received data into RX buffer
         //
         while(I2caRegs.I2CSTR.bit.RRDY!=0)
         {
             I2C_RXdata[count] = I2caRegs.I2CDRR.all;
             count++;
             //
             // set the data received flag to true to do a compare
             //
             bDataReceived = true;
         }

     }
     else if (IntSource == 0x5U) // XRDY interrupt
     {

         //
         //configure slave as transmitter
         //
         I2caRegs.I2CMDR.bit.TRX = 1;

         //
         // Disable the interrupt till all the bytes are sent
         //
         I2caRegs.I2CIER.bit.XRDY = 0;
         //
         //transmit the bytes
         //
         for(index=0; index < I2C_NUMBYTES; index++)
         {
             I2caRegs.I2CDXR.all= I2C_TXdata[index];
             //
             //wait till byte is sent
             //
             while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);
             //
             //clear the byte sent
             //
             I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
         }

         //
         // Enable the interrupt after all the bytes are sent
         //
         I2caRegs.I2CIER.bit.XRDY = 1;
     }
     //
     // Clear the current interrupt and enable future I2C (PIE Group 8) interrupts
     //
     PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
 }
