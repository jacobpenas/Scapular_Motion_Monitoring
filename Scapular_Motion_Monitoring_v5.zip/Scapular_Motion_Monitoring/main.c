#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>
#include "f28x_project.h"

// Defines
#define I2C_SLAVE_ADDR      0x01U
#define n_bits              8
#define N2                  4
#define template            0xBC
#define threshold           n_bits / 2
#define GPIO_PIN_SDAA       21U             // GPIO number for I2C SDAA
#define GPIO_PIN_SCLA       20U             // GPIO number for I2C SCLA
#define tx_pin              40              // GPIO number for PZT_POUT1 (change accordingly)
#define tx_pin_config       GPIO_40_GPIO40  // GPIO config for PZT_POUT1 (change accordingly)
// #define rx_pin                            // GPIO number for RX_OUT1
// #define rx_pin_config         // GPIO config for RX_OUT1
/* TO DO: update/add definitions for signals RX_MODE, RX_EN, PZT_NOUT, and RX_OUT */

// Globals
typedef enum {
    receive_trigger,
    transmit_pulse,
    receive_pulse,
    send_data
} states;
volatile states state = receive_trigger;
uint8_t samples[(N2 * n_bits) - (n_bits - 1)] = {0};

// Function Prototypes
void GPIO_Init(void);
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress);
void transmitPulse(void);
void receivePulse(void);
__interrupt void I2CISR(void);


void main(void)
{
    // Initialize device & 120MHz clock speed
    Device_init();
    SysCtl_setClock(
        SYSCTL_OSCSRC_OSC2  |               // Use internal oscillator
        SYSCTL_IMULT(12)    |               // Set PLL multiplier
        SYSCTL_REFDIV(1)    |               // Reference clock divider
        SYSCTL_ODIV(1)      |               // Output clock divider
        SYSCTL_SYSDIV(1)    |               // System clock divider
        SYSCTL_PLL_ENABLE                   // Enable the PLL
    );
    Device_initGPIO();

    // Initialize GPIO pins for necessary signals
    GPIO_Init();

    // .Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR)
    InitPieVectTable();

    // Register the interrupt ISR
    EALLOW;                                 // This is needed to write to EALLOW protected registers
    PieVectTable.I2CA_INT = &I2CISR;
    EDIS;                                   // This is needed to disable write to EALLOW protected registers

    // Enable Interrupts
    PieCtrlRegs.PIEIER8.all = 0x1;          // Enable PIE Group 8 INT8
    IER |= M_INT8;                          // Enable CPU INT8
    EINT;                                   // Enable Global Interrupts

    EnableInterrupts();

    // Initialize I2C Module
    I2CSlave_Init(I2C_SLAVE_ADDR);

    for(;;)
    {
        switch(state) {
        case receive_trigger:           // wait until master sends trigger
            // handled by ISR
            break;
        case transmit_pulse:            // transmit template signal
            transmitPulse();
            state = receive_pulse;
            break;
        case receive_pulse:             // read resulting signal
            receivePulse();
            state = send_data;
            break;
        case send_data:                 // send result of template matching algorithm to master
            // handled by ISR
            break;
        }
    }
}

void receivePulse(void) {
    // read pulse signal (replace pulse with reading RX_OUT pin):
/*
    // set pin to receive pulse from
    volatile uint32_t *gpioDataReg;
    uint32_t pinMask;
    gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((rx_pin / 32U) * GPIO_DATA_REGS_STEP);

    // read pulse into an array of bits (uses direct register access for 4MHz)
    uint8_t pulse[N2 * n_bits];
    uint16_t i;
    for(i = 0; i < sizeof(pulse); i++) {
        pulse[i] = ((gpioDataReg[GPIO_GPxDAT_INDEX] >> (rx_pin % 32U)) & (uint32_t)0x1U);
    }
*/
    // temporary pulse signal, should transmit 17 bytes through I2C: 4 5 4 8 4 4 4 5 5 5 5 6 4 4 4 5 8
    // only applies if N2 = 4 (template transmitted 4 times = 4 bytes received = 32 bits received (N2 * n_bits = 32))
    uint8_t pulse[N2 * n_bits] = {
        1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1,
        0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0
    };

    // perform template matching algorithm
    uint8_t shift, count = 0;
    for (shift = 0; shift < sizeof(samples); shift++) {
        // shift bit into 8-bit byte
        uint8_t bit, byte = 0;
        for (bit = 0; bit < n_bits; bit++) {
            byte = (byte << 1) | pulse[shift + bit];
        }

        // perform ~XOR operation, sum bits
        uint8_t result = ~(byte ^ template);
        uint8_t sample = 0;
        for (bit = 0; bit < n_bits; bit++) {
            sample += (result >> bit) & 1;
        }

        // store result (if greater than threshold) to samples array to be transmitted through I2C
        if (sample >= threshold) {
            samples[count++] = sample;
        }
    }
}

void transmitPulse(void) {
    // set pin to output pulse to
    volatile uint32_t *gpioDataReg;
    uint32_t pinMask;
    gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((tx_pin / 32U) * GPIO_DATA_REGS_STEP);
    pinMask = (uint32_t)1U << (tx_pin % 32U);

    // transmit template signal (0xBC = 1 0 1 1 1 1 0 0) at 4MHz
    uint16_t i;
    for (i = 0; i < N2 * n_bits; i++) {
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
    }
}

void GPIO_Init(void) {
    // Configure 4MHz template signal pin
    GPIO_setPinConfig(tx_pin_config);
    GPIO_setDirectionMode(tx_pin, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(tx_pin, GPIO_PIN_TYPE_STD);

    //Configure I2C pins
    GPIO_SetupPinMux(GPIO_PIN_SDAA, GPIO_MUX_CPU1, 11);
    GPIO_SetupPinOptions(GPIO_PIN_SDAA, GPIO_OUTPUT, GPIO_PULLUP);
    GPIO_SetupPinMux(GPIO_PIN_SCLA, GPIO_MUX_CPU1, 11);
    GPIO_SetupPinOptions(GPIO_PIN_SCLA, GPIO_OUTPUT, GPIO_PULLUP);

/* TO DO: CONFIGURE PINS FOR RX_MODE, RX_EN, PZT_POUT, PZT_NOUT, and RX_OUT */

}

// Function to configure I2CA as Slave Receiver.
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress)
{
    EALLOW;
    // Reset the I2C Module
    I2caRegs.I2CMDR.all &= ~(0x20U);

    // Configure I2C as slave in Receive mode
    I2caRegs.I2CMDR.bit.MST = 0x0U;
    I2caRegs.I2CMDR.bit.TRX = 0x0U;

    // Set the bit count to 8 bits per data byte
    I2caRegs.I2CMDR.bit.BC = 0x0U;

    // Set emulation mode to FREE
    I2caRegs.I2CMDR.bit.FREE = 0x1;

    // Configure I2C own address
    I2caRegs.I2COAR.all = I2CSlave_OwnAddress;      // Own address

    //Clear all status
    I2caRegs.I2CSTR.all = 0xFFFF;

    // Enable I2C Interrupts- AAS, STOP, XRDY and RRDY
    I2caRegs.I2CIER.all = 0x78;

    // Take I2C out of reset
    I2caRegs.I2CMDR.all |= 0x0020;

    EDIS;
}


// I2C Interrupt Service Routine
__interrupt void I2CISR(void)
{
    // Handle I2C interrupt
    uint16_t IntSource, tx_index;
    uint8_t rx_data;

    // Read Interrupt source
    IntSource = I2caRegs.I2CISRC.all;

    // Interrupt source
    if(IntSource == 0x7U)   // AAS interrupt
    {
        if(I2caRegs.I2CSTR.bit.SDIR)
        {
            // Configure slave as transmitter
            I2caRegs.I2CMDR.bit.TRX = 0x1U;
         }
         else
         {
             //Configure slave as receiver
             I2caRegs.I2CMDR.bit.TRX = 0x0U;
        }
    }
    else if(IntSource == 0x6U) // STOP interrupt
    {
        // Reset index
        tx_index = 0;
    }
    else if (IntSource == 0x4U)  // RRDY interrupt
    {
        // act only if receiving trigger
        if (state == receive_trigger) {
            // Read the received data into RX buffer
            while(I2caRegs.I2CSTR.bit.RRDY!=0)
            {
                rx_data = I2caRegs.I2CDRR.bit.DATA;     // read received data
            }

            // update state if proper trigger is received
            if (rx_data == 0xFF) {
                state = transmit_pulse;
            }
        }
    }
    else if (IntSource == 0x5U) // XRDY interrupt
    {
        // only act if sending data
        if (state == send_data) {
            //configure slave as transmitter
            I2caRegs.I2CMDR.bit.TRX = 1;

            // Disable the interrupt till all the bytes are sent
            I2caRegs.I2CIER.bit.XRDY = 0;

            //transmit the bytes (sums of ~XOR operations)
            for(tx_index=0; tx_index < sizeof(samples); tx_index++)
            {
                I2caRegs.I2CDXR.bit.DATA = samples[tx_index];

                //wait till byte is sent
                while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);

                //clear the byte sent
                I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
            }

            // Enable the interrupt after all the bytes are sent
            I2caRegs.I2CIER.bit.XRDY = 1;

            state = receive_trigger;
        }
    }

    // Clear the current interrupt and enable future I2C (PIE Group 8) interrupts
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
 }
