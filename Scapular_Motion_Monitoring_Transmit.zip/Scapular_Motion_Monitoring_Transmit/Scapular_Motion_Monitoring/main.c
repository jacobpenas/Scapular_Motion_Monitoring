#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>
#include "f28x_project.h"


#define tx_pin        40
#define tx_pin_config GPIO_40_GPIO40
#define n_bits        8

#define tx_pin1       41
#define tx_pin1_config GPIO_41_GPIO41

//#define SLAVE_ADDRESS 0x6A
//#define uint16_t 0x00000000  // Base address of internal SRAM
#define SRAM_BASE_ADDRESS 0x00000000

char data[] = "hello!";
volatile uint8_t tx_index;
volatile uint8_t rx_data;
volatile uint8_t template = 0xAA;
volatile uint8_t template_array[8] = {1, 0, 1, 0, 1, 0, 1, 0};


// Interrupt flag to track the communication
volatile uint8_t sendDataFlag = 0;
uint16_t count=0;
/*
__interrupt void i2cISR();
void i2c_enable();
*/

//
// Defines
//
#define I2C_SLAVE_ADDR 0x01U
#define MAX_BUFFER_SIZE 0x10
#define I2C_NUMBYTES    8//0x2U

//
// I2C GPIO pins
//
#define GPIO_PIN_SDAA        21U  // GPIO number for I2C SDAA
#define GPIO_PIN_SCLA        20U  // GPIO number for I2C SCLA
#define GPIO_PIN_REC         16U // GPIO number for receiver input
//

//
// Globals
//
uint16_t I2C_TXdata[MAX_BUFFER_SIZE];
uint16_t I2C_RXdata[MAX_BUFFER_SIZE];
uint16_t PassCount=0x0, FailCount =0x0;
int flag=0;

//
// Function Prototypes
//
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress);
__interrupt void I2CISR(void);

void write_to_address(volatile uint16_t *address, uint16_t data);

//
// Interrupt Handler
//
__interrupt void gpioInterruptHandler(void);

volatile uint16_t *sram_address = (uint16_t *)SRAM_BASE_ADDRESS;  // Pointer to SRAM base address4

void main(void)
{
    //uint16_t index = 0U;
    Device_init();
    SysCtl_setClock(
        SYSCTL_OSCSRC_OSC2  |               // Use internal oscillator
        SYSCTL_IMULT(12)    |               // Set PLL multiplier
        SYSCTL_REFDIV(1)    |               // Reference clock divider
        SYSCTL_ODIV(1)      |               // Output clock divider
        SYSCTL_SYSDIV(1)    |               // System clock divider
        SYSCTL_PLL_ENABLE                   // Enable the PLL
    );
    Device_initGPIO();
    //i2c_enable();

    SysCtl_selectClockOutSource(SYSCTL_CLOCKOUT_SYSCLK);
    SysCtl_setXClk(SYSCTL_XCLKOUT_DIV_1);
    GPIO_setPinConfig(GPIO_16_XCLKOUT);
    GPIO_setDirectionMode(16, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(16, GPIO_PIN_TYPE_STD);

    GPIO_setPinConfig(tx_pin_config);
    GPIO_setDirectionMode(tx_pin, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(tx_pin, GPIO_PIN_TYPE_STD);

    GPIO_setPinConfig(tx_pin_config);
    GPIO_setDirectionMode(tx_pin1, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(tx_pin1, GPIO_PIN_TYPE_STD);

    volatile uint32_t *gpioDataReg;
    uint32_t pinMask;
    gpioDataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((tx_pin / 32U) * GPIO_DATA_REGS_STEP);
    pinMask = (uint32_t)1U << (tx_pin % 32U);


    //
     //Configure I2C pins
     //

     GPIO_SetupPinMux(GPIO_PIN_SDAA, GPIO_MUX_CPU1, 11);
     GPIO_SetupPinOptions(GPIO_PIN_SDAA, GPIO_OUTPUT, GPIO_PULLUP);
     GPIO_SetupPinMux(GPIO_PIN_SCLA, GPIO_MUX_CPU1, 11);
     GPIO_SetupPinOptions(GPIO_PIN_SCLA, GPIO_OUTPUT, GPIO_PULLUP);


    //
    // .Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    //
    InitPieCtrl();

    //
    // Disable CPU interrupts and clear all CPU interrupt flags
    //
    IER = 0x0000;
    IFR = 0x0000;

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR)
    //
    InitPieVectTable();

    //
    // Register the interrupt ISR
    //
    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.I2CA_INT = &I2CISR;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    //
    // Enable Interrupts
    //
    PieCtrlRegs.PIEIER8.all = 0x1;          // Enable PIE Group 8 INT8
    IER |= M_INT8;                          // Enable CPU INT8
    EINT;                                   // Enable Global Interrupts


    // Initialize GPIO interrupt
    //initGPIOInterrupt();


    GPIO_setInterruptType(GPIO_INT_XINT1, GPIO_INT_TYPE_RISING_EDGE);
    GPIO_setInterruptPin(16, GPIO_INT_XINT1);
    GPIO_enableInterrupt(GPIO_INT_XINT1);

    Interrupt_register(INT_XINT1, &gpioInterruptHandler);
    Interrupt_enable(INT_XINT1);

    EnableInterrupts();

    //
    // Set the buffer to some default non-zero value
    //
    /*
    for (index=0; index<MAX_BUFFER_SIZE;index++)
    {
        I2C_RXdata[index] = 0xBAADU;
        //I2C_TXdata[index] = 0x11 * (index+1);
        I2C_TXdata[index] = 0x01;
    }
    */
    //uint16_t d[8]=0;

    // Initialize I2C Module
    I2CSlave_Init(I2C_SLAVE_ADDR);
    //uint16_t data_to_write[] = 0x1234;  // Data array
    //write_to_sram(data_to_write, sizeof(data_to_write) / sizeof(uint16_t));  // Write array to SRAM

    GPIO_SetupPinMux(GPIO_PIN_REC, GPIO_MUX_CPU1, 0);
    GPIO_SetupPinOptions(GPIO_PIN_REC, GPIO_INPUT, GPIO_SYNC);

    //uint16_t Buffer_receive=0;
    /*
    uint8_t Buffer_receive_upper=0;
    uint8_t Buffer_receive_lower=0;
    //uint16_t data=0;



     static int count=0;
     */
     int i;

     uint16_t array[250]={0};
     uint16_t input[313]={0};

     int count=0;
     uint16_t temp[64]={1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0};

    for(;;)
    {
        /*
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;

        DELAY_US(5);
        */



        /**********************************Transmit********************/

        /*Pulse Transmission: 11100100100111101011001100101011, 1010100101100101100101101010100110011010010110100101100110011010*/

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;


        //DELAY_US(0.16);
        //DELAY_US(0.035);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.16);
        //DELAY_US(0.035);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.16);
        //DELAY_US(0.035);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.01);
        //DELAY_US(0.16);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxSET_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);

        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        gpioDataReg[GPIO_GPxCLEAR_INDEX] = pinMask;
        //DELAY_US(0.035);
        //DELAY_US(0.16);
        //DELAY_US(0.01);
        DELAY_US(5);




      /**********************************Receive********************/

        //Buffer_receive=GPIO_ReadPin(GPIO_PIN_REC);
        //if(flag==1){
        /*sample and write data to an array*/
        /*
        array[0]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[1]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[2]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[3]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[4]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[5]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[6]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[7]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[8]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[9]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[10]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[11]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[12]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[13]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[14]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[15]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[16]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[17]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[18]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[19]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[20]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[21]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[22]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[23]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[24]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[25]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[26]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[27]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[28]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[29]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[30]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[31]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[32]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[33]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[34]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[35]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[36]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[37]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[38]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[39]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[40]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[41]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[42]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[43]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[44]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[45]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[46]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[47]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[48]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[49]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[50]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[51]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[52]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[53]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[54]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[55]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[56]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[57]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[58]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[59]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[60]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[61]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[62]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[63]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[64]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[65]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[66]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[67]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[68]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[69]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[70]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[71]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[72]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[73]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[74]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[75]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[76]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[77]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[78]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[79]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[80]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[81]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[82]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[83]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[84]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[85]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[86]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[87]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[88]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[89]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[90]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[91]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[92]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[93]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[94]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[95]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[96]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[97]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[98]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[99]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[100]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[101]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[102]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[103]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[104]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[105]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[106]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[107]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[108]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[109]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[110]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[111]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[112]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[113]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[114]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[115]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[116]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[117]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[118]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[119]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[120]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[121]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[122]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[123]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[124]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[125]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[126]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[127]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[128]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[129]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[130]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[131]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[132]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[133]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[134]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[135]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[136]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[137]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[138]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[139]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[140]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[141]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[142]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[143]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[144]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[145]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[146]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[147]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[148]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[149]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[150]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[151]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[152]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[153]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[154]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[155]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[156]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[157]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[158]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[159]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[160]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[161]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[162]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[163]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[164]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[165]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[166]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[167]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[168]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[169]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[170]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[171]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[172]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[173]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[174]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[175]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[176]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[177]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[178]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[179]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[180]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[181]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[182]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[183]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[184]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[185]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[186]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[187]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[188]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[189]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[190]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[191]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[192]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[193]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[194]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[195]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[196]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[197]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[198]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[199]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[200]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[201]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[202]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[203]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[204]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[205]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[206]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[207]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[208]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[209]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[210]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[211]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[212]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[213]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[214]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[215]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[216]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[217]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[218]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[219]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[220]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[221]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[222]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[223]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[224]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[225]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[226]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[227]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[228]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[229]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[230]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[231]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[232]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[233]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[234]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[235]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[236]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[237]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[238]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[239]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[240]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[241]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[242]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[243]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[244]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[245]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[246]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[247]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[248]=GpioDataRegs.GPADAT.bit.GPIO16;
        array[249]=GpioDataRegs.GPADAT.bit.GPIO16;
        */

        /*write the array data "array" to the SRAM address*/
        //array[100]=GpioDataRegs.GPADAT.bit.GPIO16;
        /*
        for(i=0;i<=249;i++){
            *sram_address = array[i];
            sram_address=sram_address+1;
        }
        sram_address = (uint16_t *)SRAM_BASE_ADDRESS;
        */




       /*Interpret data and save the interpreted data to a new array "input", 3 or 4 successive 0/1 is 00/11, 1 or 2 successive 0/1 is 0/1*/
       /***Original Code***/
       /*
       i=0;
       int j = 0;
       while (i<=249){

           if (array[i]==array[i+1] && array[i+1]==array[i+2] && array[i+2]==array[i+3]){

               input[j]=array[i];
               input[j+1]=array[i+1];
               i=i+4;
               j=j+2;
           }
           else if (array[i]==array[i+1] && array[i+1]==array[i+2] && array[i+2]!=array[i+3]){

               input[j]=array[i];
               input[j+1]=array[i+1];
               i=i+3;
               j=j+2;
           }
           else if (array[i]==array[i+1] && array[i+1]!=array[i+2]){

               input[j]=array[i];
               i=i+2;
               j=j+1;

           } else {

               input[j]=array[i];
               i=i+1;
               j=j+1;
           }


       }
        */

       /*
       while (i <= 249) {
           if (array[i] == array[i+1] && array[i+1] == array[i+2] && (array[i+2] == array[i+3] || array[i+2] != array[i+3])) {
               // 3 or 4 successive 0/1 -> store 2 elements
               input[j] = array[i];
               input[j+1] = array[i+1];
               i += (array[i+2] == array[i+3]) ? 4 : 3;
               j += 2;
           }
           else if (array[i] == array[i+1]) {
               // 2 successive 0/1 -> store 1 element
               input[j] = array[i];
               i += 2;
               j += 1;
           }
           else {
               // 1 successive 0/1 -> store 1 element
               input[j] = array[i];
               i += 1;
               j += 1;
           }
       }
        */

       /**********************************Signal Processing********************/



      /*zero pad the input array*/
      /***Original Code***/
      /*
      for (k=0;k<=249;k++){
          for (l=0;l<=63;l++){

              dt=(~(input[k+l] ^ temp[l]))&0x0001;
              s=s+dt;

          }
          t[k]=s;
          s=0;

      }
       */
      /*
      i=0;
      int k,l;
      uint16_t s=0;
      uint16_t t[250]={0};

      for (k = 0; k <= 249; k++) {
          s = 0;  // Reset sum at the beginning of each k iteration
          for (l = 0; l <= 63; l++) {
              s += (~(input[k + l] ^ temp[l])) & 0x0001;  // Add result to s
          }
          t[k] = s;  // Store the sum for k
      }
      */
      /******Target Detection Signal to Transfer to ESP32****/
      /*
      int h;

      for (h=0;h<=249;h++){

          if (t[h]>=60){
              I2C_TXdata[count]=1;
              break;
          } else if(h==249){

              I2C_TXdata[count]=0;

          }


      }
      count = (count + 1) % 8;
      */
      /***Original Code***/
      /*
      count=count+1;


      if (count==8){
          count=0;
      }
        */

    }

}



//
// Function to configure I2CA as Slave Receiver.
//
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress)
{

    //
    // I2C configured as slave receiver mode
    //

    EALLOW;
    //
    // Reset the I2C Module
    //
    I2caRegs.I2CMDR.all &= ~(0x20U);

    //
    // Configure I2C as slave in Receive mode
    //
    I2caRegs.I2CMDR.bit.MST = 0x0U;
    I2caRegs.I2CMDR.bit.TRX = 0x0U;

    //
    // Set the bit count to 8 bits per data byte
    //
    I2caRegs.I2CMDR.bit.BC = 0x0U;

    //
    // Set emulation mode to FREE
    //
    I2caRegs.I2CMDR.bit.FREE = 0x1;

    //
    // Configure I2C own address
    //
    I2caRegs.I2COAR.all = I2CSlave_OwnAddress;      // Own address

    //
    //Clear all status
    //
    I2caRegs.I2CSTR.all = 0xFFFF;

    //
    // Enable I2C Interrupts- AAS, STOP, XRDY and RRDY
    //
    I2caRegs.I2CIER.all = 0x78;

    //
    // Take I2C out of reset
    //
    I2caRegs.I2CMDR.all |= 0x0020;

    EDIS;
}


__interrupt void I2CISR(void)
{
    //
    // Handle I2C interrupt
    //
     uint16_t IntSource, index=0U;
     static bool bDataReceived = false;
     static volatile uint16_t count = 0U;

     //
     // Read Interrupt source
     //
     IntSource = I2caRegs.I2CISRC.all;

     //
     // Interrupt source
     //
     if(IntSource == 0x7U)   // AAS interrupt
     {
         if(I2caRegs.I2CSTR.bit.SDIR)
         {
             // Configure slave as transmitter
             I2caRegs.I2CMDR.bit.TRX = 0x1U;

         }
         else
         {
             //Configure slave as receiver
             I2caRegs.I2CMDR.bit.TRX = 0x0U;

        }
     }
     else if(IntSource == 0x6U) // STOP interrupt
     {
         //
         // Check if data has been received, then do a compare
         //
         if(bDataReceived)
         {
             bDataReceived = false;
             for(index=0; index < count; index++)
             {
                   if(I2C_RXdata[index] == I2C_TXdata[index])
                   {
                       PassCount++;
                   }
                   else
                   {
                       FailCount++;
                   }
             }
             //
             // Reinitialize the RX buffer to non-zero
             //
             if(FailCount ==0)
             {
                 for (index=0; index<count;index++)
                 {
                     I2C_RXdata[index] = 0xBAADU;
                 }
             }
             count =0U;
         }
     }
     else if (IntSource == 0x4U)  // RRDY interrupt
     {
         //
         // Read the received data into RX buffer
         //
         while(I2caRegs.I2CSTR.bit.RRDY!=0)
         {
             I2C_RXdata[count] = I2caRegs.I2CDRR.all;
             count++;
             //
             // set the data received flag to true to do a compare
             //
             bDataReceived = true;
         }

     }
     else if (IntSource == 0x5U) // XRDY interrupt
     {

         //
         //configure slave as transmitter
         //
         I2caRegs.I2CMDR.bit.TRX = 1;

         //
         // Disable the interrupt till all the bytes are sent
         //
         I2caRegs.I2CIER.bit.XRDY = 0;
         //
         //transmit the bytes
         //
         for(index=0; index < I2C_NUMBYTES; index++)
         {
             I2caRegs.I2CDXR.all= I2C_TXdata[index];
             //
             //wait till byte is sent
             //
             while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);
             //
             //clear the byte sent
             //
             I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
         }

         //
         // Enable the interrupt after all the bytes are sent
         //
         I2caRegs.I2CIER.bit.XRDY = 1;
     }
     //
     // Clear the current interrupt and enable future I2C (PIE Group 8) interrupts
     //
     PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
 }


__interrupt void gpioInterruptHandler(void)
{

    // Handle the GPIO pulse (rising edge)
    flag=1;

    // Disable the interrupt after it's triggered once
    //GpioCtrlRegs.GPAIE.bit.GPIO0 = 0;  // Disable the interrupt for GPIO0
    GPIO_disableInterrupt(GPIO_INT_XINT1);

    // Acknowledge the interrupt
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;

}

/*
void write_to_address(volatile uint16_t *address, uint16_t data) {
    *address = data;  // Write data to the specified address
}
*/
