#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <string.h>
#include "f28x_project.h"

// Defines
#define I2C_SLAVE_ADDR      0x01U
#define n_bits              8
#define N2                  4
#define template            0xBC
#define threshold           n_bits / 2
#define GPIO_PIN_SDAA       21U                 // GPIO number for I2C SDAA
#define GPIO_PIN_SCLA       20U                 // GPIO number for I2C SCLA
#define pzt_pout1           40                  // GPIO number for PZT_POUT1
#define pzt_pout1_config    GPIO_40_GPIO40      // GPIO config for PZT_POUT1
#define pzt_nout1           28                  // GPIO number for PZT_NOUT1
#define pzt_nout1_config    GPIO_28_GPIO28      // GPIO config for PZT_NOUT1
#define pzt_pout2           11                  // GPIO number for PZT_POUT1
#define pzt_pout2_config    GPIO_11_GPIO11      // GPIO config for PZT_POUT2
#define pzt_nout2           227                 // GPIO number for PZT_NOUT2
#define pzt_nout2_config    GPIO_227_GPIO227    // GPIO config for PZT_NOUT2
#define rx_out1             226                 // GPIO number for RX_OUT1
#define rx_out1_config      GPIO_226_GPIO226    // GPIO config for RX_OUT1
#define rx_out2             242                 // GPIO number for RX_OUT2
#define rx_out2_config      GPIO_242_GPIO242    // GPIO config for RX_OUT2
#define test1               7
#define test1_config        GPIO_7_GPIO7

// Globals
typedef enum {
    receive_trigger,
    transmit_pulse,
    receive_pulse,
    send_data
} states;
volatile states state = receive_trigger;
uint8_t samples1[(N2 * n_bits) - (n_bits - 1)] = {0};
uint8_t samples2[(N2 * n_bits) - (n_bits - 1)] = {0};

// Function Prototypes
void GPIO_Init(void);
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress);
void transmitPulse(void);
void receivePulse(void);
__interrupt void I2CISR(void);


void main(void)
{
    // Initialize device & 120MHz clock speed
    Device_init();
    SysCtl_setClock(
        SYSCTL_OSCSRC_OSC2  |               // Use internal oscillator
        SYSCTL_IMULT(12)    |               // Set PLL multiplier
        SYSCTL_REFDIV(1)    |               // Reference clock divider
        SYSCTL_ODIV(1)      |               // Output clock divider
        SYSCTL_SYSDIV(1)    |               // System clock divider
        SYSCTL_PLL_ENABLE                   // Enable the PLL
    );
    Device_initGPIO();

    // Initialize GPIO pins for necessary signals
    GPIO_Init();

    // .Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR)
    InitPieVectTable();

    // Register the interrupt ISR
    EALLOW;                                 // This is needed to write to EALLOW protected registers
    PieVectTable.I2CA_INT = &I2CISR;
    EDIS;                                   // This is needed to disable write to EALLOW protected registers

    // Enable Interrupts
    PieCtrlRegs.PIEIER8.all = 0x1;          // Enable PIE Group 8 INT8
    IER |= M_INT8;                          // Enable CPU INT8
    EINT;                                   // Enable Global Interrupts
    EnableInterrupts();

    // Initialize I2C Module
    I2CSlave_Init(I2C_SLAVE_ADDR);

    for(;;)
    {
        switch(state) {
        case receive_trigger:           // wait until master sends trigger
            // handled by ISR
            break;
        case transmit_pulse:            // transmit template signal
            transmitPulse();
            state = receive_pulse;
            break;
        case receive_pulse:             // read resulting signal
            receivePulse();
            state = send_data;
            break;
        case send_data:                 // send result of template matching algorithm to master
            // handled by ISR
            break;
        }
    }
}

void receivePulse(void) {
    // read pulse signal (replace pulse with reading RX_OUT pins):
/*
    // set pin to receive pulse from
    volatile uint32_t *rx_out1_dataReg;
    volatile uint32_t *rx_out2_dataReg;
    rx_out1_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((rx_out1 / 32U) * GPIO_DATA_REGS_STEP);
    rx_out2_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((rx_out2 / 32U) * GPIO_DATA_REGS_STEP);

    volatile uint32_t *test1_dataReg;
    uint32_t test1_pinMask;
    test1_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((test1 / 32U) * GPIO_DATA_REGS_STEP);
    test1_pinMask = (uint32_t)1U << (test1 % 32U);

    // read pulse into an array of bits
    uint8_t pulse1[N2 * n_bits];
    uint8_t pulse2[N2 * n_bits];
    uint16_t i;
    for(i = 0; i < N2 * n_bits; i++) {
        pulse1[i] = ((rx_out1_dataReg[GPIO_GPxDAT_INDEX] >> (rx_out1 % 32U)) & (uint32_t)0x1U);     // read RX_OUT1
        pulse2[i] = ((rx_out2_dataReg[GPIO_GPxDAT_INDEX] >> (rx_out2 % 32U)) & (uint32_t)0x1U);     // read RX_OUT2
//        test1_dataReg[GPIO_GPxSET_INDEX] = test1_pinMask;                                           // dummy instruction ?
    }
*/
    // temporary pulse signals for N2 = 4
    // pulse1: should transmit 17 bytes through I2C: 4 5 4 8 4 4 4 5 5 5 5 6 4 4 4 5 8
    uint8_t pulse1[N2 * n_bits] = {
        1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1,
        0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0
    };
    // pulse2: should transmit 22 bytes through I2C: 8 4 4 4 4 4 4 8 4 4 4 4 4 4 8 4 4 4 4 4 4 8
    uint8_t pulse2[N2 * n_bits] = {
        1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0,
        1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0
    };

    // perform template matching algorithm
    uint8_t shift, count1 = 0, count2 = 0;
    for (shift = 0; shift < (N2 * n_bits) - (n_bits - 1); shift++) {
        // shift sliding window 1 bit
        uint8_t bit, byte1 = 0, byte2 = 0;
        for (bit = 0; bit < n_bits; bit++) {
            byte1 = (byte1 << 1) | pulse1[shift + bit];
            byte2 = (byte2 << 1) | pulse2[shift + bit];
        }

        // perform ~XOR operation, sum bits
        uint8_t result1 = ~(byte1 ^ template);
        uint8_t result2 = ~(byte2 ^ template);
        uint8_t sample1 = 0, sample2 = 0;
        for (bit = 0; bit < n_bits; bit++) {
            sample1 += (result1 >> bit) & 1;
            sample2 += (result2 >> bit) & 1;
        }

        // store result (if greater than threshold) to samples array to be transmitted through I2C
        if (sample1 >= threshold) {
            samples1[count1++] = sample1;
        }
        if (sample2 >= threshold) {
            samples2[count2++] = sample2;
        }
    }
}

void transmitPulse(void) {
    // set pins to output pulse to
    volatile uint32_t *pzt_pout1_dataReg;
    volatile uint32_t *pzt_nout1_dataReg;
    volatile uint32_t *pzt_pout2_dataReg;
    volatile uint32_t *pzt_nout2_dataReg;
    uint32_t pzt_pout1_pinMask, pzt_nout1_pinMask, pzt_pout2_pinMask, pzt_nout2_pinMask;
    pzt_pout1_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((pzt_pout1 / 32U) * GPIO_DATA_REGS_STEP);
    pzt_pout1_pinMask = (uint32_t)1U << (pzt_pout1 % 32U);
    pzt_nout1_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((pzt_nout1 / 32U) * GPIO_DATA_REGS_STEP);
    pzt_nout1_pinMask = (uint32_t)1U << (pzt_nout1 % 32U);
    pzt_pout2_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((pzt_pout2 / 32U) * GPIO_DATA_REGS_STEP);
    pzt_pout2_pinMask = (uint32_t)1U << (pzt_pout2 % 32U);
    pzt_nout2_dataReg = (uint32_t *)((uintptr_t)GPIODATA_BASE) + ((pzt_nout2 / 32U) * GPIO_DATA_REGS_STEP);
    pzt_nout2_pinMask = (uint32_t)1U << (pzt_nout2 % 32U);

    // transmit template signal (0xBC = 1 0 1 1 1 1 0 0) at 4MHz
/********************** CURRENTLY TRANSMITS AT 3MHz, NOT 4MHz **********************/
    uint16_t i;
    for (i = 0; i < N2 * n_bits; i++) {
        pzt_pout1_dataReg[GPIO_GPxSET_INDEX] = pzt_pout1_pinMask;       // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout1_pinMask;     // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxSET_INDEX] = pzt_pout2_pinMask;       // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout2_pinMask;     // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_pout1_pinMask;     // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxSET_INDEX] = pzt_nout1_pinMask;       // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_pout2_pinMask;     // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxSET_INDEX] = pzt_nout2_pinMask;       // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxSET_INDEX] = pzt_pout1_pinMask;       // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout1_pinMask;     // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxSET_INDEX] = pzt_pout2_pinMask;       // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout2_pinMask;     // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxSET_INDEX] = pzt_pout1_pinMask;       // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout1_pinMask;     // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxSET_INDEX] = pzt_pout2_pinMask;       // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout2_pinMask;     // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxSET_INDEX] = pzt_pout1_pinMask;       // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout1_pinMask;     // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxSET_INDEX] = pzt_pout2_pinMask;       // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout2_pinMask;     // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxSET_INDEX] = pzt_pout1_pinMask;       // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout1_pinMask;     // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxSET_INDEX] = pzt_pout2_pinMask;       // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_nout2_pinMask;     // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_pout1_pinMask;     // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxSET_INDEX] = pzt_nout1_pinMask;       // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_pout2_pinMask;     // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxSET_INDEX] = pzt_nout2_pinMask;       // pzt_nout2

        pzt_pout1_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_pout1_pinMask;     // pzt_pout1
        pzt_nout1_dataReg[GPIO_GPxSET_INDEX] = pzt_nout1_pinMask;       // pzt_nout1
        pzt_pout2_dataReg[GPIO_GPxCLEAR_INDEX] = pzt_pout2_pinMask;     // pzt_pout2
        pzt_nout2_dataReg[GPIO_GPxSET_INDEX] = pzt_nout2_pinMask;       // pzt_nout2
    }
}

void GPIO_Init(void) {
    // TEST1
    GPIO_setPinConfig(test1_config);
    GPIO_setDirectionMode(test1, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(test1, GPIO_PIN_TYPE_STD);

    // PZT_POUT1
    GPIO_setPinConfig(pzt_pout1_config);
    GPIO_setDirectionMode(pzt_pout1, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(pzt_pout1, GPIO_PIN_TYPE_STD);

    // PZT_NOUT1
    GPIO_setPinConfig(pzt_nout1_config);
    GPIO_setDirectionMode(pzt_nout1, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(pzt_nout1, GPIO_PIN_TYPE_STD);

    // PZT_POUT2
    GPIO_setPinConfig(pzt_pout2_config);
    GPIO_setDirectionMode(pzt_pout2, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(pzt_pout2, GPIO_PIN_TYPE_STD);

    // PZT_NOUT2
    GPIO_setPinConfig(pzt_nout2_config);
    GPIO_setDirectionMode(pzt_nout2, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(pzt_nout2, GPIO_PIN_TYPE_STD);

    // RX_MODE1 (GPIO 5)
    GPIO_setPinConfig(GPIO_5_GPIO5);
    GPIO_setDirectionMode(5, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(5, GPIO_PIN_TYPE_STD);
    GPIO_writePin(5, 0);

    // RX_MODE2 (GPIO 24)
    GPIO_setPinConfig(GPIO_24_GPIO24);
    GPIO_setDirectionMode(24, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(24, GPIO_PIN_TYPE_STD);
    GPIO_writePin(24, 0);

    // RX_EN1 (GPIO 3)
    GPIO_setPinConfig(GPIO_3_GPIO3);
    GPIO_setDirectionMode(3, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(3, GPIO_PIN_TYPE_STD);
    GPIO_writePin(3, 1);

    // RX_EN2 (GPIO 4)
    GPIO_setPinConfig(GPIO_4_GPIO4);
    GPIO_setDirectionMode(4, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(4, GPIO_PIN_TYPE_STD);
    GPIO_writePin(4, 1);

    // RX_OUT1 (GPIO 226)
    GPIO_setPinConfig(GPIO_226_GPIO226);
    GPIO_setDirectionMode(226, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(226, GPIO_PIN_TYPE_STD);

    // RX_OUT2 (GPIO 242)
    GPIO_setPinConfig(GPIO_242_GPIO242);
    GPIO_setDirectionMode(242, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(242, GPIO_PIN_TYPE_STD);

    // I2C pins
    GPIO_SetupPinMux(GPIO_PIN_SDAA, GPIO_MUX_CPU1, 11);
    GPIO_SetupPinOptions(GPIO_PIN_SDAA, GPIO_OUTPUT, GPIO_PULLUP);
    GPIO_SetupPinMux(GPIO_PIN_SCLA, GPIO_MUX_CPU1, 11);
    GPIO_SetupPinOptions(GPIO_PIN_SCLA, GPIO_OUTPUT, GPIO_PULLUP);
}

// Function to configure I2CA as Slave Receiver
void I2CSlave_Init(uint16_t I2CSlave_OwnAddress)
{
    EALLOW;
    // Reset the I2C Module
    I2caRegs.I2CMDR.all &= ~(0x20U);

    // Configure I2C as slave in Receive mode
    I2caRegs.I2CMDR.bit.MST = 0x0U;
    I2caRegs.I2CMDR.bit.TRX = 0x0U;

    // Set the bit count to 8 bits per data byte
    I2caRegs.I2CMDR.bit.BC = 0x0U;

    // Set emulation mode to FREE
    I2caRegs.I2CMDR.bit.FREE = 0x1;

    // Configure I2C own address
    I2caRegs.I2COAR.all = I2CSlave_OwnAddress;      // Own address

    //Clear all status
    I2caRegs.I2CSTR.all = 0xFFFF;

    // Enable I2C Interrupts- AAS, STOP, XRDY and RRDY
    I2caRegs.I2CIER.all = 0x78;

    // Take I2C out of reset
    I2caRegs.I2CMDR.all |= 0x0020;

    EDIS;
}


// I2C Interrupt Service Routine
__interrupt void I2CISR(void)
{
    // Handle I2C interrupt
    uint16_t IntSource, tx_index1, tx_index2;
    uint8_t rx_data;

    // Read Interrupt source
    IntSource = I2caRegs.I2CISRC.all;

    // Interrupt source
    if(IntSource == 0x7U)   // AAS interrupt
    {
        if(I2caRegs.I2CSTR.bit.SDIR)
        {
            // Configure slave as transmitter
            I2caRegs.I2CMDR.bit.TRX = 0x1U;
         }
         else
         {
             // Configure slave as receiver
             I2caRegs.I2CMDR.bit.TRX = 0x0U;
        }
    }
    else if(IntSource == 0x6U) // STOP interrupt
    {
        // reset index
        tx_index1 = 0;
        tx_index2 = 0;
    }
    else if (IntSource == 0x4U)  // RRDY interrupt
    {
        // act only if receiving trigger
        if (state == receive_trigger) {
            // Read the received data into RX buffer
            while(I2caRegs.I2CSTR.bit.RRDY!=0)
            {
                // read received data
                rx_data = I2caRegs.I2CDRR.bit.DATA;
            }

            // update state if proper trigger is received
            if (rx_data == 0xFF) {
                state = transmit_pulse;
            }
        }
    }
    else if (IntSource == 0x5U) // XRDY interrupt
    {
        // only act if sending data
        if (state == send_data) {
            // configure slave as transmitter
            I2caRegs.I2CMDR.bit.TRX = 1;

            // Disable the interrupt till all the bytes are sent
            I2caRegs.I2CIER.bit.XRDY = 0;

            // transmit the bytes (sums of ~XOR operations)
            for(tx_index1 = 0; tx_index1 < sizeof(samples1); tx_index1++)
            {
                I2caRegs.I2CDXR.bit.DATA = samples1[tx_index1];

                // wait till byte is sent
                while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);

                // clear the byte sent
                I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
            }

            for (tx_index2 = 0; tx_index2 < sizeof(samples2); tx_index2++)
            {
                I2caRegs.I2CDXR.bit.DATA = samples2[tx_index2];
                while(I2caRegs.I2CSTR.bit.BYTESENT != 0x1);
                I2caRegs.I2CSTR.bit.BYTESENT = 0x1;
            }

            // Enable the interrupt after all the bytes are sent
            I2caRegs.I2CIER.bit.XRDY = 1;

            // Update state (after all data is transferred)
            state = receive_trigger;
        }
    }

    // Clear the current interrupt and enable future I2C (PIE Group 8) interrupts
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
 }
